/*  Scenario 1: The bank wants to apply a discount to loan interest rates for customers above 60 years old.
 Question: Write a PL/SQL block that loops through all customers, checks their age, and if they are above 60, apply a 1% discount to their current loan interest rates.*/

DECLARE
  CURSOR c_customers IS
    SELECT CustomerID, (TRUNC(MONTHS_BETWEEN(SYSDATE, DOB) / 12)) AS Age FROM Customers;v_customerID Loans.CustomerID%TYPE;v_age NUMBER;
BEGIN
  FOR r_customer IN c_customers LOOP
    v_customerID := r_customer.CustomerID;
    v_age := r_customer.Age;
    IF v_age > 60 THEN
      UPDATE Loans SET InterestRate = InterestRate * 0.99 WHERE CustomerID = v_customerID;
    END IF;
  END LOOP;
  COMMIT;
END;

/*Scenario 2: A customer can be promoted to VIP status based on their balance.
 Question: Write a PL/SQL block that iterates through all customers and sets a flag IsVIP to TRUE for those with a balance over $10,000.*/

ALTER TABLE Customers ADD IsVIP VARCHAR2(5) DEFAULT 'FALSE';
BEGIN
    FOR customer_rec IN (SELECT CustomerID, Balance FROM Customers) LOOP
        IF customer_rec.Balance > 10000 THEN
            UPDATE Customers SET IsVIP = 'TRUE', LastModified = SYSDATE
            WHERE CustomerID = customer_rec.CustomerID;
        END IF;
    END LOOP;
END;

/*Scenario 3: The bank wants to send reminders to customers whose loans are due within the next 30 days.
 Question: Write a PL/SQL block that fetches all loans due in the next 30 days and prints a reminder message for each customer.*/

DECLARE
    CURSOR loan_cursor IS
        SELECT l.LoanID, l.CustomerID, l.EndDate, c.Name FROM Loans l JOIN Customers c ON l.CustomerID = c.CustomerID WHERE l.EndDate BETWEEN SYSDATE AND SYSDATE + 30;
    v_loan_due_date DATE;
    v_customer_name VARCHAR2(100);
BEGIN
    OPEN loan_cursor;
    LOOP
        FETCH loan_cursor INTO v_loan_due_date, v_customer_name;
        EXIT WHEN loan_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('Reminder: Dear ' || v_customer_name || 
                             ', your loan is due on ' || TO_CHAR(v_loan_due_date, 'YYYY-MM-DD') || 
                             '. Please ensure timely payment.');
    END LOOP;
    CLOSE loan_cursor;
END;

/*Scenario 1: Handle exceptions during fund transfers between accounts.
 Question: Write a stored procedure SafeTransferFunds that transfers funds between two accounts. Ensure that if any error occurs (e.g., insufficient funds), an appropriate error message is logged and the transaction is rolled back.*/

CREATE TABLE ErrorLogs (LogID NUMBER PRIMARY KEY,ErrorMessage VARCHAR2(4000),ErrorDate DATE DEFAULT SYSDATE);
CREATE OR REPLACE PROCEDURE SafeTransferFunds ( p_FromAccountID IN NUMBER, p_ToAccountID IN NUMBER, p_Amount IN NUMBER) AS v_FromBalance NUMBER;v_ToBalance NUMBER;v_ErrorMessage VARCHAR2(4000);
BEGIN
    SELECT Balance INTO v_FromBalance FROM Accounts WHERE AccountID = p_FromAccountID FOR UPDATE;
    IF v_FromBalance < p_Amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in the source account.');
    END IF;
    UPDATE Accounts SET Balance = Balance - p_Amount, LastModified = SYSDATE WHERE AccountID = p_FromAccountID;
    UPDATE Accounts SET Balance = Balance + p_Amount, LastModified = SYSDATE WHERE AccountID = p_ToAccountID;
    INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType) VALUES (TRANSACTIONS_SEQ.NEXTVAL, p_FromAccountID, SYSDATE, -p_Amount, 'DEBIT');
    INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType) VALUES (TRANSACTIONS_SEQ.NEXTVAL, p_ToAccountID, SYSDATE, p_Amount, 'CREDIT');
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN v_ErrorMessage := SQLERRM;
        INSERT INTO ErrorLogs (LogID, ErrorMessage, ErrorDate)VALUES (ERRORLOGS_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
        ROLLBACK;
        RAISE;
END SafeTransferFunds;

/*Scenario 2: Manage errors when updating employee salaries.
 Question: Write a stored procedure UpdateSalary that increases the salary of an employee by a given percentage. If the employee ID does not exist, handle the exception and log an error message.*/

 CREATE OR REPLACE PROCEDURE UpdateSalary (p_EmployeeID IN NUMBER,p_Percentage IN NUMBER) AS v_CurrentSalary NUMBER;v_NewSalary NUMBER;v_ErrorMessage VARCHAR2(4000);
BEGIN
    SELECT Salary INTO v_CurrentSalary FROM Employees WHERE EmployeeID = p_EmployeeID FOR UPDATE;
    v_NewSalary := v_CurrentSalary * (1 + p_Percentage / 100);
    UPDATE Employees SET Salary = v_NewSalary,LastModified = SYSDATE WHERE EmployeeID = p_EmployeeID;
    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN v_ErrorMessage := 'Employee ID ' || p_EmployeeID || ' does not exist.';
        INSERT INTO ErrorLogs (LogID, ErrorMessage, ErrorDate)VALUES (ERRORLOGS_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
        ROLLBACK;

    WHEN OTHERS THEN v_ErrorMessage := 'Error updating salary for Employee ID ' || p_EmployeeID || ': ' || SQLERRM;
        INSERT INTO ErrorLogs (LogID, ErrorMessage, ErrorDate) VALUES (ERRORLOGS_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
        ROLLBACK;
        RAISE;
END UpdateSalary;

/*Scenario 3: Ensure data integrity when adding a new customer.
 Question: Write a stored procedure AddNewCustomer that inserts a new customer into the Customers table. If a customer with the same ID already exists, handle the exception by logging an error and preventing the insertion.*/

 CREATE OR REPLACE PROCEDURE AddNewCustomer ( p_CustomerID IN NUMBER, p_Name IN VARCHAR2, p_DOB IN DATE, p_Balance IN NUMBER)ASv_ErrorMessage VARCHAR2(4000);
BEGIN
    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)VALUES (p_CustomerID, p_Name, p_DOB, p_Balance, SYSDATE);
    COMMIT;
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN v_ErrorMessage := 'Customer ID ' || p_CustomerID || ' already exists.';
        INSERT INTO ErrorLogs (LogID, ErrorMessage, ErrorDate) VALUES (ERRORLOGS_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
        ROLLBACK;

    WHEN OTHERS THEN v_ErrorMessage := 'Error adding customer with ID ' || p_CustomerID || ': ' || SQLERRM;
        INSERT INTO ErrorLogs (LogID, ErrorMessage, ErrorDate)VALUES (ERRORLOGS_SEQ.NEXTVAL, v_ErrorMessage, SYSDATE);
        ROLLBACK;
        RAISE;
END AddNewCustomer;

/*Scenario 1: The bank needs to process monthly interest for all savings accounts.
 Question: Write a stored procedure ProcessMonthlyInterest that calculates and updates the balance of all savings accounts by applying an interest rate of 1% to the current balance.*/

CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest AS v_InterestRate CONSTANT NUMBER := 0.01;v_NewBalance NUMBER;
BEGIN
    FOR acc_rec IN (SELECT AccountID, Balance FROM Accounts WHERE AccountType = 'Savings' FOR UPDATE) LOOP
        v_NewBalance := acc_rec.Balance * (1 + v_InterestRate);
        UPDATE Accounts SET Balance = v_NewBalance, LastModified = SYSDATE WHERE AccountID = acc_rec.AccountID;
        INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)VALUES (TRANSACTIONS_SEQ.NEXTVAL, acc_rec.AccountID, SYSDATE, v_NewBalance - acc_rec.Balance, 'CREDIT');
    END LOOP;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20002, 'Error processing monthly interest: ' || SQLERRM);
END ProcessMonthlyInterest;

/*Scenario 2: The bank wants to implement a bonus scheme for employees based on their performance.
 Question: Write a stored procedure UpdateEmployeeBonus that updates the salary of employees in a given department by adding a bonus percentage passed as a parameter.*/

CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (p_Department IN VARCHAR2,p_BonusPercentage IN NUMBER)AS v_NewSalary NUMBER;
BEGIN
    FOR emp_rec IN (SELECT EmployeeID, Salary FROM Employees WHERE Department = p_Department FOR UPDATE) LOOP
        v_NewSalary := emp_rec.Salary * (1 + p_BonusPercentage / 100);
        UPDATE Employees SET Salary = v_NewSalary WHERE EmployeeID = emp_rec.EmployeeID;
    END LOOP;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20003, 'Error updating employee bonuses: ' || SQLERRM);
END UpdateEmployeeBonus;

/*Scenario 3: Customers should be able to transfer funds between their accounts.
 Question: Write a stored procedure TransferFunds that transfers a specified amount from one account to another, checking that the source account has sufficient balance before making the transfer.*/

CREATE OR REPLACE PROCEDURE TransferFunds ( p_SourceAccountID IN NUMBER, p_DestinationAccountID IN NUMBER, p_Amount IN NUMBER)AS v_SourceBalance NUMBER;
BEGIN
    SELECT Balance INTO v_SourceBalance FROM Accounts WHERE AccountID = p_SourceAccountID FOR UPDATE;
    IF v_SourceBalance < p_Amount THEN RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in the source account.');
    ELSE UPDATE Accounts SET Balance = Balance - p_Amount, LastModified = SYSDATE WHERE AccountID = p_SourceAccountID;
        UPDATE Accounts SET Balance = Balance + p_Amount,LastModified = SYSDATE WHERE AccountID = p_DestinationAccountID;
        INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)VALUES (TRANSACTIONS_SEQ.NEXTVAL, p_SourceAccountID, SYSDATE, p_Amount, 'DEBIT');
        INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)VALUES (TRANSACTIONS_SEQ.NEXTVAL, p_DestinationAccountID, SYSDATE, p_Amount, 'CREDIT');
    END IF;
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20002, 'Error during fund transfer: ' || SQLERRM);
END TransferFunds;

/*Scenario 1: Calculate the age of customers for eligibility checks.
 Question: Write a function CalculateAge that takes a customer's date of birth as input and returns their age in years.*/

CREATE OR REPLACE FUNCTION CalculateAge (p_DOB IN DATE) RETURN NUMBER AS v_Age NUMBER;
BEGIN
    SELECT FLOOR(MONTHS_BETWEEN(SYSDATE, p_DOB) / 12) INTO v_Age FROM dual;
    RETURN v_Age;
END CalculateAge;
SELECT Name, DOB, CalculateAge(DOB) AS Age FROM Customers;

/*Scenario 2: The bank needs to compute the monthly installment for a loan.
 Question: Write a function CalculateMonthlyInstallment that takes the loan amount, interest rate, and loan duration in years as input and returns the monthly installment amount.*/

CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment (p_LoanAmount IN NUMBER,p_InterestRate IN NUMBER, p_LoanDuration IN NUMBER ) RETURN NUMBER AS v_MonthlyRate NUMBER;v_NumPayments NUMBER;v_MonthlyInstallment NUMBER;
BEGIN
    v_MonthlyRate := p_InterestRate / 100 / 12;
    v_NumPayments := p_LoanDuration * 12;
    IF v_MonthlyRate = 0 THEN v_MonthlyInstallment := p_LoanAmount / v_NumPayments;
    ELSE v_MonthlyInstallment := (p_LoanAmount * v_MonthlyRate * POWER(1 + v_MonthlyRate, v_NumPayments)) / (POWER(1 + v_MonthlyRate, v_NumPayments) - 1);
    END IF;
    RETURN v_MonthlyInstallment;
END CalculateMonthlyInstallment;

/*Scenario 3: Check if a customer has sufficient balance before making a transaction.
 Question: Write a function HasSufficientBalance that takes an account ID and an amount as input and returns a boolean indicating whether the account has at least the specified amount.*/

CREATE OR REPLACE FUNCTION HasSufficientBalance (p_AccountID IN NUMBER,p_Amount IN NUMBER) RETURN BOOLEAN AS v_Balance NUMBER;
BEGIN
    SELECT Balance INTO v_Balance FROM Accounts WHERE AccountID = p_AccountID;
    IF v_Balance >= p_Amount THEN RETURN TRUE;
    ELSE RETURN FALSE;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN FALSE;
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'Error checking account balance: ' || SQLERRM);
END HasSufficientBalance;

DECLARE v_HasBalance BOOLEAN;
BEGIN v_HasBalance := HasSufficientBalance(101, 500);
  IF v_HasBalance THEN DBMS_OUTPUT.PUT_LINE('Sufficient balance available.');
  ELSE DBMS_OUTPUT.PUT_LINE('Insufficient balance.');
  END IF;
END;

/*Scenario 1: Automatically update the last modified date when a customer's record is updated.
 Question: Write a trigger UpdateCustomerLastModified that updates the LastModified column of the Customers table to the current date whenever a customer's record is updated.*/

CREATE OR REPLACE TRIGGER UpdateCustomerLastModified BEFORE UPDATE ON Customers FOR EACH ROW
BEGIN
    :NEW.LastModified := SYSDATE;
END;

UPDATE Customers SET Balance = Balance + 100 WHERE CustomerID = 1;

/*Scenario 2: Maintain an audit log for all transactions.
 Question: Write a trigger LogTransaction that inserts a record into an AuditLog table whenever a transaction is inserted into the Transactions table*/

CREATE SEQUENCE AuditLogSeq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
INSERT INTO Transactions (TransactionID,AccountID,TransactionDate,Amount,TransactionType) VALUES (1,101,SYSDATE,500,'Deposit');

/*Scenario 3: Enforce business rules on deposits and withdrawals.
Question: Write a trigger CheckTransactionRules that ensures withdrawals do not exceed the balance and deposits are positive before inserting a record into the Transactions table.*/

CREATE OR REPLACE TRIGGER CheckTransactionRules BEFORE INSERT ON Transactions FOR EACH ROW
DECLARE v_AccountBalance NUMBER;
BEGIN
    SELECT Balance INTO v_AccountBalance FROM Accounts WHERE AccountID = :NEW.AccountID;
    IF :NEW.TransactionType = 'Withdrawal' THEN
        IF :NEW.Amount > v_AccountBalance THEN
            RAISE_APPLICATION_ERROR(-20001, 'Insufficient balance for withdrawal.');
        END IF;
    ELSIF :NEW.TransactionType = 'Deposit' THEN
        IF :NEW.Amount <= 0 THEN
            RAISE_APPLICATION_ERROR(-20002, 'Deposit amount must be positive.');
        END IF;
    ELSE
        RAISE_APPLICATION_ERROR(-20003, 'Invalid transaction type. Only Deposit or Withdrawal are allowed.');
    END IF;
END;

/*Scenario 1: Generate monthly statements for all customers.
 Question: Write a PL/SQL block using an explicit cursor GenerateMonthlyStatements that retrieves all transactions for the current month and prints a statement for each customer.*/

DECLARE
    CURSOR transaction_cursor IS
        SELECT c.CustomerID, c.Name, a.AccountID, t.TransactionID, t.TransactionDate, t.Amount, t.TransactionType FROM Transactions t JOIN Accounts a ON t.AccountID = a.AccountID JOIN Customers c ON a.CustomerID = c.CustomerID WHERE EXTRACT(MONTH FROM t.TransactionDate) = EXTRACT(MONTH FROM SYSDATE) AND EXTRACT(YEAR FROM t.TransactionDate) = EXTRACT(YEAR FROM SYSDATE) ORDER BY c.CustomerID, a.AccountID, t.TransactionDate;
    v_CustomerID Customers.CustomerID%TYPE; v_Name Customers.Name%TYPE; v_AccountID Accounts.AccountID%TYPE; v_TransactionID Transactions.TransactionID%TYPE;v_TransactionDate Transactions.TransactionDate%TYPE;v_Amount Transactions.Amount%TYPE;v_TransactionType Transactions.TransactionType%TYPE;
BEGIN
    OPEN transaction_cursor;
    LOOP
        FETCH transaction_cursor INTO v_CustomerID, v_Name, v_AccountID, v_TransactionID, v_TransactionDate, v_Amount, v_TransactionType;
        EXIT WHEN transaction_cursor%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('Customer: ' || v_Name || ' (ID: ' || v_CustomerID || ')');
        DBMS_OUTPUT.PUT_LINE('Account ID: ' || v_AccountID);
        DBMS_OUTPUT.PUT_LINE('Transaction ID: ' || v_TransactionID);
        DBMS_OUTPUT.PUT_LINE('Date: ' || TO_CHAR(v_TransactionDate, 'DD-MON-YYYY'));
        DBMS_OUTPUT.PUT_LINE('Amount: ' || v_Amount);
        DBMS_OUTPUT.PUT_LINE('Type: ' || v_TransactionType);
    END LOOP;
    CLOSE transaction_cursor;
END;

/*Scenario 2: Apply annual fee to all accounts.
Question: Write a PL/SQL block using an explicit cursor ApplyAnnualFee that deducts an annual maintenance fee from the balance of all accounts.*/

DECLARE annual_fee NUMBER := 50;
    CURSOR account_cursor IS SELECT AccountID, Balance FROM Accounts ORDER BY AccountID;
    v_AccountID Accounts.AccountID%TYPE; v_Balance Accounts.Balance%TYPE;
BEGIN
    OPEN account_cursor;
    LOOP
        FETCH account_cursor INTO v_AccountID, v_Balance;
        EXIT WHEN account_cursor%NOTFOUND; UPDATE Accounts SET Balance = Balance - annual_fee, LastModified = SYSDAT WHERE AccountID = v_AccountID;
            INSERT INTO Transactions (TransactionID,AccountID,TransactionDate,Amount,TransactionType) VALUES (Transactions_SEQ.NEXTVAL,v_AccountID,SYSDATE, -annual_fee, 'Fee');
        ELSE
            DBMS_OUTPUT.PUT_LINE('Insufficient balance for Account ID ' || v_AccountID);
        END IF;
    END LOOP;
    CLOSE account_cursor;
    DBMS_OUTPUT.PUT_LINE('Annual fee application completed.');
END;

/*Scenario 3: Update the interest rate for all loans based on a new policy.
Question: Write a PL/SQL block using an explicit cursor UpdateLoanInterestRates that fetches all loans and updates their interest rates based on the new policy.*/

DECLARE new_interest_rate NUMBER := 0.05; 
    CURSOR loan_cursor IS SELECT LoanID, InterestRate FROM Loans ORDER BY LoanID;
    v_LoanID Loans.LoanID%TYPE; v_CurrentInterestRate Loans.InterestRate%TYPE;
BEGIN
    OPEN loan_cursor;
    LOOP
        FETCH loan_cursor INTO v_LoanID, v_CurrentInterestRate;
        EXIT WHEN loan_cursor%NOTFOUND;
        UPDATE Loans SET InterestRate = new_interest_rate, LastModified = SYSDATE WHERE LoanID = v_LoanID;
        DBMS_OUTPUT.PUT_LINE('Updated LoanID ' || v_LoanID || ' from InterestRate ' || v_CurrentInterestRate || ' to ' || new_interest_rate);
    END LOOP;
    CLOSE loan_cursor;
    DBMS_OUTPUT.PUT_LINE('Interest rates update completed.');
END;

/*Scenario 1: Group all customer-related procedures and functions into a package.
Question: Create a package CustomerManagement with procedures for adding a new customer, updating customer details, and a function to get customer balance.*/

CREATE OR REPLACE PACKAGE CustomerManagement AS PROCEDURE AddNewCustomer(p_CustomerID IN NUMBER, p_Name IN VARCHAR2, p_DOB IN DATE, p_Balance IN NUMBER); PROCEDURE UpdateCustomerDetails(p_CustomerID IN NUMBER, p_Name IN VARCHAR2, p_DOB IN DATE, p_Balance IN NUMBER); FUNCTION GetCustomerBalance(p_CustomerID IN NUMBER) RETURN NUMBER;
END CustomerManagement;

CREATE OR REPLACE PACKAGE BODY CustomerManagement AS PROCEDURE AddNewCustomer(p_CustomerID IN NUMBER, p_Name IN VARCHAR2, p_DOB IN DATE, p_Balance IN NUMBER) IS
    BEGIN
        BEGIN
            INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified) VALUES (p_CustomerID, p_Name, p_DOB, p_Balance, SYSDATE);
        EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN DBMS_OUTPUT.PUT_LINE('Error: Customer with ID ' || p_CustomerID || ' already exists.');
            WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        END;
    END AddNewCustomer;
    PROCEDURE UpdateCustomerDetails(p_CustomerID IN NUMBER, p_Name IN VARCHAR2, p_DOB IN DATE, p_Balance IN NUMBER) IS
    BEGIN
        BEGIN
            UPDATE Customers SET Name = p_Name,DOB = p_DOB,Balance = p_Balance,LastModified = SYSDATE WHERE CustomerID = p_CustomerID;
            IF SQL%ROWCOUNT = 0 THEN DBMS_OUTPUT.PUT_LINE('Error: Customer with ID ' || p_CustomerID || ' does not exist.');
            END IF;
        EXCEPTION
            WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        END;
    END UpdateCustomerDetails;
    FUNCTION GetCustomerBalance(p_CustomerID IN NUMBER) RETURN NUMBER IS v_Balance NUMBER;
    BEGIN
        BEGIN
            SELECT Balance INTO v_Balance FROM Customers WHERE CustomerID = p_CustomerID;RETURN v_Balance;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('Error: Customer with ID ' || p_CustomerID || ' does not exist.'); RETURN NULL;
            WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM); RETURN NULL;
        END;
    END GetCustomerBalance;
END CustomerManagement;

/*Scenario 2: Create a package to manage employee data.
Question: Write a package EmployeeManagement with procedures to hire new employees, update employee details, and a function to calculate annual salary.*/

CREATE OR REPLACE PACKAGE BODY EmployeeManagement AS PROCEDURE HireEmployee(p_EmployeeID IN NUMBER, p_Name IN VARCHAR2, p_Position IN VARCHAR2, p_Salary IN NUMBER, p_Department IN VARCHAR2, p_HireDate IN DATE) IS
    BEGIN
        BEGIN
            INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)VALUES (p_EmployeeID, p_Name, p_Position, p_Salary, p_Department, p_HireDate);
        EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN DBMS_OUTPUT.PUT_LINE('Error: Employee with ID ' || p_EmployeeID || ' already exists.');
            WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        END;
    END HireEmployee;
    PROCEDURE UpdateEmployeeDetails(p_EmployeeID IN NUMBER, p_Name IN VARCHAR2, p_Position IN VARCHAR2, p_Salary IN NUMBER, p_Department IN VARCHAR2) IS
    BEGIN
        BEGIN
            UPDATE Employees SET Name = p_Name,Position = p_Position,Salary = p_Salary,Department = p_Department WHERE EmployeeID = p_EmployeeID;
            IF SQL%ROWCOUNT = 0 THEN DBMS_OUTPUT.PUT_LINE('Error: Employee with ID ' || p_EmployeeID || ' does not exist.');
            END IF;
        EXCEPTION
            WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        END;
    END UpdateEmployeeDetails;
    FUNCTION CalculateAnnualSalary(p_EmployeeID IN NUMBER) RETURN NUMBER IS v_Salary NUMBER;
    BEGIN
        BEGIN SELECT Salary INTO v_Salary FROM Employees WHERE EmployeeID = p_EmployeeID; RETURN v_Salary * 12; 
        EXCEPTION
            WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('Error: Employee with ID ' || p_EmployeeID || ' does not exist.');RETURN NULL;
            WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM); RETURN NULL;
        END;
    END CalculateAnnualSalary;
END EmployeeManagement;

/*Scenario 3: Group all account-related operations into a package.
Question: Create a package AccountOperations with procedures for opening a new account, closing an account, and a function to get the total balance of a customer across all accounts.*/

CREATE OR REPLACE PACKAGE BODY AccountOperations AS PROCEDURE OpenAccount(p_AccountID IN NUMBER, p_CustomerID IN NUMBER, p_AccountType IN VARCHAR2, p_Balance IN NUMBER) IS
    BEGIN
        BEGIN
            INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)VALUES (p_AccountID, p_CustomerID, p_AccountType, p_Balance, SYSDATE);
        EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN DBMS_OUTPUT.PUT_LINE('Error: Account with ID ' || p_AccountID || ' already exists.');
            WHEN FOREIGN_KEY_CONSTRAINT THEN DBMS_OUTPUT.PUT_LINE('Error: Customer with ID ' || p_CustomerID || ' does not exist.');
            WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        END;
    END OpenAccount;
    PROCEDURE CloseAccount(p_AccountID IN NUMBER) IS
    BEGIN
        BEGIN
            DELETE FROM Accounts WHERE AccountID = p_AccountID;
            IF SQL%ROWCOUNT = 0 THEN DBMS_OUTPUT.PUT_LINE('Error: Account with ID ' || p_AccountID || ' does not exist or is already closed.');
            END IF;
        EXCEPTION
            WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        END;
    END CloseAccount;
    FUNCTION GetTotalBalance(p_CustomerID IN NUMBER) RETURN NUMBER IS v_TotalBalance NUMBER;
    BEGIN
        BEGIN
            SELECT SUM(Balance) INTO v_TotalBalance FROM Accounts WHERE CustomerID = p_CustomerID; RETURN NVL(v_TotalBalance, 0); 
        EXCEPTION
            WHEN NO_DATA_FOUND THEN DBMS_OUTPUT.PUT_LINE('Error: Customer with ID ' || p_CustomerID || ' does not have any accounts.'); RETURN 0;
            WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);RETURN 0;
        END;
    END GetTotalBalance;
END AccountOperations;
