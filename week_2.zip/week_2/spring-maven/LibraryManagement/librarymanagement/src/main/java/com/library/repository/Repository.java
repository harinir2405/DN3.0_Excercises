package com.library.repository;

public class Repository {
    public void repo() {
        System.out.println("this is repo class");
    }
}
