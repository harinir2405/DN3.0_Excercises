package javax.persistence;

public class Cacheable {

}
