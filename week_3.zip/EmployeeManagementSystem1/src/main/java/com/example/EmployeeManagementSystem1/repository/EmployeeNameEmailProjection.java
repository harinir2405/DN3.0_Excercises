package com.example.EmployeeManagementSystem1.repository;

public interface EmployeeNameEmailProjection {
    String getName();
    String getEmail();
}
