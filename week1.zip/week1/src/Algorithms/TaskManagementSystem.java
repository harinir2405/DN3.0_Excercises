/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Algorithms;

/**
 *
 * @author HP
 */
class Task {
    private String taskId;
    private String taskName;
    private String status;

    public Task(String taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    // Getters
    public String getTaskId() {
        return taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Task [taskId=" + taskId + ", taskName=" + taskName + ", status=" + status + "]";
    }
}

class Node {
    Task task;
    Node next;

    public Node(Task task) {
        this.task = task;
        this.next = null;
    }
}

class TaskManagementSystem {
    private Node head;

    public TaskManagementSystem() {
        this.head = null;
    }

    // Add Task
    public void addTask(Task task) {
        Node newNode = new Node(task);
        newNode.next = head;
        head = newNode;
    }

    // Search Task
    public Task searchTask(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId().equals(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Traverse Tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete Task
    public boolean deleteTask(String taskId) {
        Node current = head;
        Node previous = null;

        while (current != null && !current.task.getTaskId().equals(taskId)) {
            previous = current;
            current = current.next;
        }

        if (current == null) { // Task not found
            return false;
        }

        if (previous == null) { // Task is at head
            head = current.next;
        } else {
            previous.next = current.next;
        }

        return true;
    }

    public static void main(String[] args) {
        TaskManagementSystem tm = new TaskManagementSystem();

        // Adding tasks
        tm.addTask(new Task("T001", "Design Database", "Pending"));
        tm.addTask(new Task("T002", "Develop API", "In Progress"));
        tm.addTask(new Task("T003", "Create UI", "Completed"));
        tm.addTask(new Task("T004", "Testing", "Yet To Start"));

        // Traversing tasks
        System.out.println("Traversing Tasks:");
        tm.traverseTasks();

        // Searching for a task
        System.out.println("\nSearching for Task T003:");
        Task task = tm.searchTask("T003");
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found.");
        }

        // Deleting a task
        System.out.println("\nDeleting Task T003:");
        if (tm.deleteTask("T003")) {
            System.out.println("Task deleted.");
        } else {
            System.out.println("Task not found.");
        }

        // Traversing tasks after deletion
        System.out.println("\nTraversing Tasks after Deletion:");
        tm.traverseTasks();
    }
}
