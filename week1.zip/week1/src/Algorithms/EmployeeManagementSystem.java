/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Algorithms;

/**
 *
 * @author HP
 */
class Employee {
    private String employeeId;
    private String name;
    private String position;
    private double salary;

    public Employee(String employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    // Getters
    public String getEmployeeId() {
        return employeeId;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee [employeeId=" + employeeId + ", name=" + name + ", position=" + position + ", salary=" + salary + "]";
    }
}

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;
    private int capacity;

    public EmployeeManagementSystem(int capacity) {
        this.capacity = capacity;
        this.employees = new Employee[capacity];
        this.size = 0;
    }

    // Add Employee
    public boolean addEmployee(Employee employee) {
        if (size >= capacity) {
            System.out.println("Array is full. Cannot add employee.");
            return false;
        }
        employees[size++] = employee;
        return true;
    }

    // Search Employee
    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse Employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete Employee
    public boolean deleteEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                employees[i] = employees[size - 1]; // Replace with the last employee
                employees[size - 1] = null; // Nullify the last element
                size--;
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        EmployeeManagementSystem em = new EmployeeManagementSystem(5);

        // Adding employees
        em.addEmployee(new Employee("E001", "Ali", "Manager", 75000));
        em.addEmployee(new Employee("E002", "Bala", "Developer", 60000));
        em.addEmployee(new Employee("E003", "Chandru", "Designer", 50000));
        em.addEmployee(new Employee("E004", "Hari", "Programmer", 80000));

        // Traversing employees
        System.out.println("Traversing Employees:");
        em.traverseEmployees();

        // Searching for an employee
        System.out.println("\nSearching for Employee E002:");
        Employee emp = em.searchEmployee("E002");
        if (emp != null) {
            System.out.println(emp);
        } else {
            System.out.println("Employee not found.");
        }

        // Deleting an employee
        System.out.println("\nDeleting Employee E002:");
        if (em.deleteEmployee("E002")) {
            System.out.println("Employee deleted.");
        } else {
            System.out.println("Employee not found.");
        }

        // Traversing employees after deletion
        System.out.println("\nTraversing Employees after Deletion:");
        em.traverseEmployees();
    }
}

