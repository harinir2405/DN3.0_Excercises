/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Algorithms;

/**
 *
 * @author HP
 */
import java.util.HashMap;

class Product {
    private String productId;
    private String productName;
    private int quantity;
    private double price;

    public Product(String productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    // Getters and Setters
    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product [productId=" + productId + ", productName=" + productName + ", quantity=" + quantity + ", price="
                + price + "]";
    }
}

class Inventory {
    private HashMap<String, Product> products;

    public Inventory() {
        products = new HashMap<>();
    }

    // Method to add a product
    public void addProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    // Method to update a product
    public void updateProduct(String productId, Product product) {
        if (products.containsKey(productId)) {
            products.put(productId, product);
        } else {
            System.out.println("Product not found!");
        }
    }

    // Method to delete a product
    public void deleteProduct(String productId) {
        products.remove(productId);
    }

    // Method to retrieve a product
    public Product getProduct(String productId) {
        return products.get(productId);
    }
}

public class InventoryManagementSystem {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        // Adding products
        Product product1 = new Product("P001", "Product 1", 100, 10.0);
        Product product2 = new Product("P002", "Product 2", 200, 20.0);

        inventory.addProduct(product1);
        inventory.addProduct(product2);

        // Updating a product
        Product updatedProduct1 = new Product("P001", "Updated Product 1", 150, 15.0);
        inventory.updateProduct("P001", updatedProduct1);

        // Deleting a product
        inventory.deleteProduct("P002");

        // Retrieving and displaying a product
        Product retrievedProduct = inventory.getProduct("P001");
        System.out.println(retrievedProduct);
    }
}
