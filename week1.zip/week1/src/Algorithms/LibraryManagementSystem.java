/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Algorithms;

/**
 *
 * @author HP
 */
class Book {
    private String bookId;
    private String title;
    private String author;

    public Book(String bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    // Getters
    public String getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    @Override
    public String toString() {
        return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + "]";
    }
}

public class LibraryManagementSystem {
    private Book[] books;
    private int size;

    public LibraryManagementSystem(Book[] books) {
        this.books = books;
        this.size = books.length;
    }

    // Linear Search
    public Book linearSearch(String title) {
        for (int i = 0; i < size; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }

    // Binary Search
    public Book binarySearch(String title) {
        int left = 0;
        int right = size - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);
            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Book[] books = {
            new Book("B001", "The Silent Patient", "Alex Michaelides"),
            new Book("B002", "A Good Girl's Guide To Murder", "Holly Jackson"),
            new Book("B003", "Verity", "Colleen Hoover"),
            new Book("B004", "Pride and Prejudice", "Jane Austen"),
            new Book("B005", "The Cruel Prince", "Holly Black")
        };

        LibraryManagementSystem lm = new LibraryManagementSystem(books);

        // Linear Search
        System.out.println("Linear Search for 'Verity':");
        Book book = lm.linearSearch("Verity");
        if (book != null) {
            System.out.println(book);
        } else {
            System.out.println("Book not found.");
        }

        // Binary Search (assuming the array is sorted by title)
        System.out.println("\nBinary Search for 'Verity':");
        book = lm.binarySearch("Verity");
        if (book != null) {
            System.out.println(book);
        } else {
            System.out.println("Book not found.");
        }
    }
}

