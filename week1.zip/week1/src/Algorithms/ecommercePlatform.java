/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Algorithms;

/**
 *
 * @author HP
 */
import java.util.Arrays;

class Product implements Comparable<Product> {
    private final String productId;
    private final String productName;
    private final String category;

    public Product(String productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }

    // Getters
    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getCategory() {
        return category;
    }

    @Override
    public int compareTo(Product other) {
        return this.productName.compareTo(other.productName);
    }

    @Override
    public String toString() {
        return "Product [productId=" + productId + ", productName=" + productName + ", category=" + category + "]";
    }
}

public class ecommercePlatform {

    // Linear Search
    public static Product linearSearch(Product[] products, String productName) {
        for (Product product : products) {
            if (product.getProductName().equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null;
    }

    // Binary Search
    public static Product binarySearch(Product[] products, String productName) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int result = products[mid].getProductName().compareToIgnoreCase(productName);

            if (result == 0) {
                return products[mid];
            } else if (result < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product("P001", "Laptop", "Electronics"),
            new Product("P002", "Mobile phone", "Electronics"),
            new Product("P003", "Refrigerator", "Electronics"),
            new Product("P004", "Headphones", "Accessories"),
            new Product("P005", "Smartwatch", "Accessories")
        };

        // Linear Search
        Product foundProductLinear = linearSearch(products, "Refrigerator");
        System.out.println("Linear Search Result: " + foundProductLinear);

        // Sort products array for Binary Search
        Arrays.sort(products);

        // Binary Search
        Product foundProductBinary = binarySearch(products, "Refrigerator");
        System.out.println("Binary Search Result: " + foundProductBinary);
    }
}

