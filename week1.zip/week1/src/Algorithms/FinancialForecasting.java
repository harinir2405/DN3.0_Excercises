/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Algorithms;

/**
 *
 * @author HP
 */
import java.util.HashMap;
import java.util.Map;

public class FinancialForecasting {

    private static Map<Integer, Double> memo = new HashMap<>();

    // Recursive method to calculate future value with memoization
    public static double predictFutureValue(double presentValue, double growthRate, int years) {
        // Base case
        if (years == 0) {
            return presentValue;
        }
        // Check if result is already computed
        if (memo.containsKey(years)) {
            return memo.get(years);
        }
        // Recursive case
        double futureValue = predictFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
        memo.put(years, futureValue);
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1700; // Example present value
        double annualGrowthRate = 0.10; // Example annual growth rate (5%)
        int years = 10; // Number of years to predict

        double futureValue = predictFutureValue(presentValue, annualGrowthRate, years);
        System.out.println("Future value after " + years + " years: " + futureValue);
    }
}


