/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Design_Patterns;

/**
 *
 * @author HP
 */
public class AdapterPattern{

    // Target interface
    public interface PaymentProcessor {
        void processPayment(double amount);
    }

    // Adaptee classes
    public static class StripeGateway {
        public void chargeCard(double amount) {
            System.out.println("Charging $" + amount + " through Stripe.");
        }
    }

    public static class PayPalGateway {
        public void makePayment(double amount) {
            System.out.println("Processing $" + amount + " payment through PayPal.");
        }
    }

    // Adapter classes
    public static class StripeAdapter implements PaymentProcessor {
        private StripeGateway stripeGateway;

        public StripeAdapter(StripeGateway stripeGateway) {
            this.stripeGateway = stripeGateway;
        }

        @Override
        public void processPayment(double amount) {
            stripeGateway.chargeCard(amount);
        }
    }

    public static class PayPalAdapter implements PaymentProcessor {
        private PayPalGateway payPalGateway;

        public PayPalAdapter(PayPalGateway payPalGateway) {
            this.payPalGateway = payPalGateway;
        }

        @Override
        public void processPayment(double amount) {
            payPalGateway.makePayment(amount);
        }
    }

    // Main class to test the Adapter Pattern
    public static void main(String[] args) {
        // Create instances of third-party payment gateways
        StripeGateway stripeGateway = new StripeGateway();
        PayPalGateway payPalGateway = new PayPalGateway();

        // Create adapters for the payment gateways
        PaymentProcessor stripeProcessor = new StripeAdapter(stripeGateway);
        PaymentProcessor payPalProcessor = new PayPalAdapter(payPalGateway);

        // Process payments using the adapters
        stripeProcessor.processPayment(150.0);
        payPalProcessor.processPayment(200.0);
    }
}
