/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Design_Patterns;

/**
 *
 * @author HP
 */
public class DecoratorPattern {

    // Component Interface
    public interface Notifier {
        void send(String message);
    }

    // Concrete Component
    public static class EmailNotifier implements Notifier {
        @Override
        public void send(String message) {
            System.out.println("Sending Email with message: " + message);
        }
    }

    // Decorator Abstract Class
    public static abstract class NotifierDecorator implements Notifier {
        protected Notifier decoratedNotifier;

        public NotifierDecorator(Notifier decoratedNotifier) {
            this.decoratedNotifier = decoratedNotifier;
        }

        @Override
        public void send(String message) {
            decoratedNotifier.send(message);
        }
    }

    // Concrete Decorator for SMS
    public static class SMSNotifierDecorator extends NotifierDecorator {
        public SMSNotifierDecorator(Notifier decoratedNotifier) {
            super(decoratedNotifier);
        }

        @Override
        public void send(String message) {
            super.send(message); // Send email
            sendSMS(message);    // Then send SMS
        }

        private void sendSMS(String message) {
            System.out.println("Sending SMS with message: " + message);
        }
    }

    // Concrete Decorator for Slack
    public static class SlackNotifierDecorator extends NotifierDecorator {
        public SlackNotifierDecorator(Notifier decoratedNotifier) {
            super(decoratedNotifier);
        }

        @Override
        public void send(String message) {
            super.send(message); // Send email
            sendSlack(message);  // Then send Slack message
        }

        private void sendSlack(String message) {
            System.out.println("Sending Slack message with: " + message);
        }
    }

    // Main class to test the Decorator Pattern
    public static void main(String[] args) {
        // Create a base email notifier
        Notifier emailNotifier = new EmailNotifier();

        // Decorate it with SMS and Slack notifiers
        Notifier smsAndEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackAndEmailNotifier = new SlackNotifierDecorator(emailNotifier);

        // Send notifications
        System.out.println("Sending notifications with SMS and Email:");
        smsAndEmailNotifier.send("Good Day!");

        System.out.println("\nSending notifications with Slack and Email:");
        slackAndEmailNotifier.send("Good Day!");
    }
}

