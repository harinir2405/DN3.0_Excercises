/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Design_Patterns;

/**
 *
 * @author HP
 */
public class ProxyPattern {

    // Subject Interface
    public interface Image {
        void display();
    }

    // Real Subject Class
    public static class RealImage implements Image {
        private String fileName;

        public RealImage(String fileName) {
            this.fileName = fileName;
            loadImageFromServer();
        }

        private void loadImageFromServer() {
            System.out.println("Loading image: " + fileName);
            // Simulate loading image from a remote server
            try {
                Thread.sleep(2000); // Simulate delay
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void display() {
            System.out.println("Displaying image: " + fileName);
        }
    }

    // Proxy Class
    public static class ProxyImage implements Image {
        private RealImage realImage;
        private String fileName;
        private boolean isImageLoaded;

        public ProxyImage(String fileName) {
            this.fileName = fileName;
            this.isImageLoaded = false;
        }

        @Override
        public void display() {
            if (!isImageLoaded) {
                realImage = new RealImage(fileName);
                isImageLoaded = true;
            }
            realImage.display();
        }
    }

    // Main class to test the Proxy Pattern
    public static void main(String[] args) {
        // Create proxy images
        Image image1 = new ProxyImage("pic1.jpg");
        Image image2 = new ProxyImage("pic2.jpg");

        // Display images
        System.out.println("Displaying images:");
        image1.display(); 
        image1.display(); 

        image2.display(); 
        image2.display(); 
    }
}
