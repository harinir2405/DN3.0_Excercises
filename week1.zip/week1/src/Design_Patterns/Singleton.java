/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Design_Patterns;

/**
 *
 * @author HP
 */
public class Singleton {

    // Singleton class
    public static class Logger {
        // Private static instance of the same class
        private static Logger instance;

        // Private constructor to prevent instantiation
        private Logger() {
            // Initialization code (if any)
        }

        // Public method to provide access to the instance
        public static Logger getInstance() {
            if (instance == null) {
                instance = new Logger();
            }
            return instance;
        }

        // Example method to log messages
        public void log(String message) {
            System.out.println("Log message: " + message);
        }
    }

    // Test class
    public static class SingletonTest {
        public static void main(String[] args) {
            // Get the single instance of Logger
            Logger log1 = Logger.getInstance();
            Logger log2 = Logger.getInstance();

            // Test if both references point to the same instance
            if (log1 == log2) {
                System.out.println("Both log1 and log2 refer to the same instance.");
            } else {
                System.out.println("log1 and log2 are different instances.");
            }

            // Use the Logger instance to log messages
            log1.log("This is the first log message.");
            log2.log("This is the second log message.");
        }
    }
}

