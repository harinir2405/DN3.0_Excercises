/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Design_Patterns;

/**
 *
 * @author HP
 */
public class DependencyInjection{

    // Repository Interface
    public interface CustomerRepository {
        String findCustomerById(int id);
    }

    // Concrete Repository
    public static class CustomerRepositoryImpl implements CustomerRepository {
        @Override
        public String findCustomerById(int id) {
            // Simulate retrieving a customer from a database
            return "Customer with ID: " + id;
        }
    }

    // Service Class
    public static class CustomerService {
        private CustomerRepository customerRepository;

        // Constructor Injection
        public CustomerService(CustomerRepository customerRepository) {
            this.customerRepository = customerRepository;
        }

        public String getCustomerDetails(int id) {
            return customerRepository.findCustomerById(id);
        }
    }

    // Test Class
    public static void main(String[] args) {
        // Create a concrete repository instance
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        // Inject the repository into the service
        CustomerService customerService = new CustomerService(customerRepository);

        // Use the service to find a customer
        String customerDetails = customerService.getCustomerDetails(1);
        System.out.println(customerDetails);
    }
}
