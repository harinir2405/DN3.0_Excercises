/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Design_Patterns;

/**
 *
 * @author HP
 */
public class CommandPattern {

    // Command Interface
    public interface Command {
        void execute();
    }

    // Receiver Class
    public static class Light {
        public void turnOn() {
            System.out.println("The light is on.");
        }

        public void turnOff() {
            System.out.println("The light is off.");
        }
    }

    // Concrete Command - LightOnCommand
    public static class LightOnCommand implements Command {
        private Light light;

        public LightOnCommand(Light light) {
            this.light = light;
        }

        @Override
        public void execute() {
            light.turnOn();
        }
    }

    // Concrete Command - LightOffCommand
    public static class LightOffCommand implements Command {
        private Light light;

        public LightOffCommand(Light light) {
            this.light = light;
        }

        @Override
        public void execute() {
            light.turnOff();
        }
    }

    // Invoker Class
    public static class RemoteControl {
        private Command command;

        public void setCommand(Command command) {
            this.command = command;
        }

        public void pressButton() {
            command.execute();
        }
    }

    // Test Class
    public static void main(String[] args) {
        // Create receiver
        Light light = new Light();

        // Create concrete commands
        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        // Create invoker
        RemoteControl remote = new RemoteControl();

        // Turn on the light
        remote.setCommand(lightOn);
        System.out.println("Press button to turn on the light:");
        remote.pressButton();

        // Turn off the light
        remote.setCommand(lightOff);
        System.out.println("Press button to turn off the light:");
        remote.pressButton();
    }
}

