/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Design_Patterns;

/**
 *
 * @author HP
 */
public class FactoryMethod {

    // Document interface
    public interface Document {
        void open();
    }

    // Concrete document classes
    public static class MSWordDocument implements Document {
        @Override
        public void open() {
            System.out.println("Opening MSWord document.");
        }
    }

    public static class PdfDocument implements Document {
        @Override
        public void open() {
            System.out.println("Opening PDF document.");
        }
    }

    public static class ExcelDocument implements Document {
        @Override
        public void open() {
            System.out.println("Opening Excel document.");
        }
    }

    // DocumentFactory abstract class
    public abstract static class DocumentFactory {
        public abstract Document createDocument();
    }

    // Concrete factory classes
    public static class MSWordDocumentFactory extends DocumentFactory {
        @Override
        public Document createDocument() {
            return new MSWordDocument();
        }
    }

    public static class PdfDocumentFactory extends DocumentFactory {
        @Override
        public Document createDocument() {
            return new PdfDocument();
        }
    }

    public static class ExcelDocumentFactory extends DocumentFactory {
        @Override
        public Document createDocument() {
            return new ExcelDocument();
        }
    }

    // Main class to test the Factory Method Pattern
    public static void main(String[] args) {
        // Create factories for different document types
        DocumentFactory MSwordFactory = new MSWordDocumentFactory();
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        DocumentFactory excelFactory = new ExcelDocumentFactory();

        // Create and open Word document
        Document wordDoc = MSwordFactory.createDocument();
        wordDoc.open();

        // Create and open PDF document
        Document pdfDoc = pdfFactory.createDocument();
        pdfDoc.open();

        // Create and open Excel document
        Document excelDoc = excelFactory.createDocument();
        excelDoc.open();
    }
}
