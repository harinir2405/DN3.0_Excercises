/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Design_Patterns;

/**
 *
 * @author HP
 */
public class StrategyPattern {

    // Strategy Interface
    public interface PaymentStrategy {
        void pay(double amount);
    }

    // Concrete Strategy - CreditCardPayment
    public static class CreditCardPayment implements PaymentStrategy {
        private String cardNumber;
        private String cardHolderName;

        public CreditCardPayment(String cardNumber, String cardHolderName) {
            this.cardNumber = cardNumber;
            this.cardHolderName = cardHolderName;
        }

        @Override
        public void pay(double amount) {
            System.out.println("Processing credit card payment of $" + amount +
                    " for card number " + cardNumber + " (Cardholder: " + cardHolderName + ")");
        }
    }

    // Concrete Strategy - PayPalPayment
    public static class PayPalPayment implements PaymentStrategy {
        private String email;

        public PayPalPayment(String email) {
            this.email = email;
        }

        @Override
        public void pay(double amount) {
            System.out.println("Processing PayPal payment of $" + amount + " for email " + email);
        }
    }

    // Context Class
    public static class PaymentContext {
        private PaymentStrategy paymentStrategy;

        public PaymentContext(PaymentStrategy paymentStrategy) {
            this.paymentStrategy = paymentStrategy;
        }

        public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
            this.paymentStrategy = paymentStrategy;
        }

        public void executePayment(double amount) {
            paymentStrategy.pay(amount);
        }
    }

    // Test Class
    public static void main(String[] args) {
        // Create different payment strategies
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9087-6543", "Harini");
        PaymentStrategy payPalPayment = new PayPalPayment("hariniabc@example.com");

        // Create the context and set the initial payment strategy
        PaymentContext paymentContext = new PaymentContext(creditCardPayment);

        // Execute payment using the current strategy
        System.out.println("Making payment using Credit Card:");
        paymentContext.executePayment(1250.75);

        // Change payment strategy to PayPal
        paymentContext.setPaymentStrategy(payPalPayment);

        // Execute payment using the new strategy
        System.out.println("\nMaking payment using PayPal:");
        paymentContext.executePayment(1900.50);
    }
}
